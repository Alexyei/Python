import re
from Fraction import Fraction
from calculator import evaluate

numbers = {"ноль": '0', "один": '1', "одна": '1', "два": '2', "две": '2', "три": '3', "четыре": '4', "пять": '5',
           "шесть": '6', "семь": '7',
           "восемь": '8', "девять": '9', "десять": '10', "одиннадцать": '11', "двенадцать": '12',
           "тринадцать": '13', "четырнадцать": '14', "пятнадцать": '15', "шестнадцать": '16', "семнадцать": '17',
           "восемнадцать": '18', "девятнадцать": '19', "двадцать": '20', "тридцать": '30', "сорок": '40',
           "пятьдесят": '50', "шестьдесят": '60', "семьдесят": '70', "восемьдесят": '80', "девяносто": '90'}
operators = {"плюс": '+', "минус": '-', "умножить на": '*', "разделить на": "/", "и": "?",
             "скобка открывается": "(", "скобка закрывается": ")"}
denominators = {"первых": '1' + ' #', "вторых": '2' + ' #', "третьих": '3' + ' #', "четвёртых": '4' + ' #',
                "пятых": '5' + ' #', "шестых": '6' + ' #',
                "седьмых": '7' + ' #', "восьмых": '8' + ' #', "девятых": '9' + ' #', "десятых": '10' + ' #',
                "одиннадцатых": '11' + ' #',
                "двенадцатых": '12' + ' #', "тринадцатых": '13' + ' #', "четырнадцатых": '14' + ' #',
                "пятнадцатых": '15' + ' #',
                "шестнадцатых": '16' + ' #', "семнадцатых": '17' + ' #', "восемнадцатых": '18' + ' #',
                "девятнадцатых": '19' + ' #',
                "двадцатых": '20' + ' #', "тридцатых": '30' + ' #', "сороковых": '40' + ' #',
                "пятидесятых": '50' + ' #', "шестидесятых": '60' + ' #',
                "семидесятых": '70' + ' #', "восьмидесятых": '80' + ' #', "девяностая": '90' + ' #',
                "первая": '1' + ' #', "вторая": '2' + ' #', "третья": '3' + ' #', "четвёртая": '4' + ' #',
                "пятая": '5' + ' #', "шестая": '6' + ' #',
                "седьмая": '7' + ' #', "восьмая": '8' + ' #', "девятая": '9' + ' #', "десятая": '10' + ' #',
                "одиннадцатая": '11' + ' #',
                "двенадцатая": '12' + ' #', "тринадцатая": '13' + ' #', "четырнадцатая": '14' + ' #',
                "пятнадцатая": '15' + ' #',
                "шестнадцатая": '16' + ' #', "семнадцатая": '17' + ' #', "восемнадцатая": '18' + ' #',
                "девятнадцатая": '19' + ' #',
                "двадцатая": '20' + ' #', "тридцатая": '30' + ' #', "сороковая": '40' + ' #',
                "пятидесятая": '50' + ' #', "шестидесятая": '60' + ' #',
                "семидесятая": '70' + ' #', "восьмидесятая": '80' + ' #', "девяностых": '90' + ' #'
                }


def getKeyByValue(dict, value):
    return list(dict.keys())[list(dict.values()).index(value)]


def wordsToExpression(text):
    text = text.lower()
    if bool(re.search(r"[^а-яё ]", text)):
        raise SyntaxError("В исходном выражении содержаться недопустимые символы")

    words = dict(numbers)
    words.update(operators)
    words.update(denominators)

    for word, value in words.items():
        text = re.sub(fr"\b{word}\b", ' ' + value, text)

    if bool(re.search(r"[^+\-*/#()?0-9 ]", text)):
        raise SyntaxError("В исходном выражении содержаться недопустимые слова")

    if not balanced(text):
        raise SyntaxError("Скобки раставлены неверно")

    return list(filter(None, text.split(' ')))


def isInt(value):
    try:
        return int(value), True
    except ValueError:
        return value, False


def accumulateNumbers(expressionList):
    i = 0
    sumFlag = False
    while (i < len(expressionList)):
        (value, isNumber) = isInt(expressionList[i])
        if isNumber:
            expressionList[i] = value
            if value >= 20 and value % 10 == 0:
                sumFlag = True
            if sumFlag and value < 10:
                expressionList[i - 1:i + 1] = [expressionList[i - 1] + expressionList[i]]
                i -= 1
                sumFlag = False
        else:
            sumFlag = False
        i += 1

    return expressionList


def numberExpressionToFractions(numberExpressionList):
    numberExpressionList.append("f")
    i = 0
    mixedFlag = False
    fraction = []

    def createFraction():
        nonlocal fraction
        nonlocal mixedFlag
        nonlocal i
        if fraction:
            if mixedFlag and len(fraction) == 3:
                frac = Fraction(fraction[0] * fraction[-1] + fraction[1], fraction[-1])
                numberExpressionList[i - 4:i + 1] = [frac]
                i -= 4
                mixedFlag = False
            elif not mixedFlag:
                if numberExpressionList[i] == "#":
                    if len(fraction) == 2:
                        frac = Fraction(fraction[0], fraction[1])
                        numberExpressionList[i - 2:i + 1] = [frac]
                        i -= 2
                    else:
                        raise SyntaxError("Ошибка в записи числа")
                else:
                    if len(fraction) == 1:
                        frac = Fraction(fraction[0], 1)
                        numberExpressionList[i - 1] = frac
                    else:
                        raise SyntaxError("Ошибка в записи числа")
            else:
                raise SyntaxError("Ошибка в записи числа")
            fraction = []

    while (i < len(numberExpressionList)):
        if isinstance(numberExpressionList[i], int):
            fraction.append(numberExpressionList[i])
        elif numberExpressionList[i] == "?":
            if mixedFlag:
                raise SyntaxError("Дублирование союза 'и' в выражении")
            mixedFlag = True
        else:
            createFraction()
        i += 1

    numberExpressionList.pop()

    return numberExpressionList


def checkFractionExpression(fractionExpression):
    # s - start of list "n()+-*/"
    lastEl = "s"
    canDoublePlusFlag = False
    canDoubleMinusFlag = False
    for i in range(len(fractionExpression)):
        if isinstance(fractionExpression[i], Fraction):
            if lastEl in "n)":
                raise SyntaxError("Ошибка порядка элементов в выражении")
            lastEl = "n"
        elif fractionExpression[i] in "*/":
            # n)
            if lastEl in "s(*/+-":
                raise SyntaxError("Ошибка порядка элементов в выражении")
            lastEl = fractionExpression[i]
        elif fractionExpression[i] == "+":
            if lastEl in "*/-":
                raise SyntaxError("Ошибка порядка элементов в выражении")
            if lastEl in "n)":
                canDoublePlusFlag = True
            elif lastEl == "+":
                if canDoublePlusFlag:
                    canDoublePlusFlag = False
                else:
                    raise SyntaxError("Недопустимый повтор +")
            lastEl = fractionExpression[i]
        elif fractionExpression[i] == "-":
            if lastEl in "*/+":
                raise SyntaxError("Ошибка порядка элементов в выражении")
            if lastEl in "n)":
                canDoubleMinusFlag = True
            elif lastEl == "-":
                if canDoubleMinusFlag:
                    canDoubleMinusFlag = False
                else:
                    raise SyntaxError("Недопустимый повтор -")
            lastEl = fractionExpression[i]
        elif fractionExpression[i] == "(":
            if lastEl in "n)":
                raise SyntaxError("Ошибка порядка элементов в выражении")
            lastEl = "("
        elif fractionExpression[i] == ")":
            if lastEl in "s*/+-":
                raise SyntaxError("Ошибка порядка элементов в выражении")
            lastEl = ")"
        else:
            raise SyntaxError("Ошибка дублирования элементов в выражении")

    if lastEl in "*/-+(s":
        raise SyntaxError("Выражение не завершенно")


def balanced(s):
    pairs = {"{": "}", "(": ")", "[": "]"}
    stack = []
    for c in s:
        if c in "{[(":
            stack.append(c)
        elif c in "}])":
            if stack and c == pairs[stack[-1]]:
                stack.pop()
            else:
                return False
    return len(stack) == 0


def uintToWord(number, words, den=False):
    if number > 20 and number % 10:
        return getKeyByValue(words, str(number - number % 10)) + " " + getKeyByValue(words, str(
            number % 10) + (" #" if den else ""))
    else:
        return getKeyByValue(words, str(number) + (" #" if den else ""))


def fractionToStr(frac):
    result = ""

    (val, num, den) = frac.getElements()
    if any(map(lambda el: abs(el) >= 100, frac.getElements())):
        if den == 1:
            return str(val)
        if val:
            result = str(val) + " и "
        result += str(num) + " / " + str(den)
    else:
        if den == 1:
            if val < 0:
                result = "минус "
                val *= -1
            result += uintToWord(val, numbers)
            return result
        if val:
            if val < 0:
                result = "минус "
                val *= -1

            result += uintToWord(val, numbers) + " и "
        if num < 0:
            result = "минус "
            num *= -1
        result += uintToWord(num, numbers) + " "
        words = dict(numbers)
        words.update(denominators)
        result += uintToWord(den, words, True)

    return result


def evalExpression(expression):
    lstExp = numberExpressionToFractions(accumulateNumbers(wordsToExpression(expression)))
    checkFractionExpression(lstExp)
    result = evaluate(lstExp)
    return fractionToStr(result)


def calculator(expression):
    print(expression)
    try:
        print(" = " + evalExpression(expression))
    except Exception as e:
        print("Ошибка: " + str(e))


def main():
    print("Допустимые выражения: ")
    calculator(evalExpression(
        "скобка открывается плюс пять и одна вторая плюс скобка открывается минус семь скобка закрывается умножить на пять скобка закрывается разделить на одна вторая плюс пять третьих"))
    calculator(
        "скобка открывается плюс пять и одна вторая плюс плюс семь и семь седьмых плюс скобка открывается минус семь скобка закрывается умножить на пять скобка закрывается разделить на одна вторая плюс пять третьих")
    calculator("    пять   плюс     семь   ")
    calculator("скобка открывается скобка открывается пять плюс семь скобка закрывается скобка закрывается")
    calculator("пять умножить на скобка открывается плюс семь скобка закрывается")
    calculator("пять минус минус семь")
    calculator("пять плюс плюс семь")
    calculator("пять плюс скобка открывается минус семь скобка закрывается")
    calculator("минус семь плюс семь и одна четвёртая")
    calculator("девяносто плюс девяносто")
    calculator("девяносто и одна четвёртая плюс девяносто и одна пятая")
    calculator("минус пять девяностых плюс семь пятидесятых")
    longStr = ["скобка открывается скобка открывается" +
               " скобка открывается минус пять плюс пять и одна четвёртая скобка закрывается" +
               " умножить на скобка открывается минус пять и одна восьмая плюс плюс семь и " +
               "две четвёртых скобка закрывается плюс скобка открывается минус ноль умножить на " +
               "скобка открывается плюс семь и одна пятидесятая скобка закрывается разделить на " +
               "скобка открывается минус семь девятых скобка закрывается скобка закрывается скобка закрывается"
               + " плюс скобка открывается плюс семь четвёртых умножить на скобка открывается плюс пять вторых " +
               "скобка закрывается скобка закрывается скобка закрывается разделить на скобка открывается " +
               "пятнадцать и шестнадцать четвёртых умножить на семь вторых скобка закрывается умножить на " +
               "семь и одна четвёртая разделить на скобка открывается минус четыре скобка закрывается "
               + "плюс семь умножить на два и пять вторых"]
    calculator(*longStr)

    print("Некорректные выражения")
    calculator("- пять плюс семь")
    calculator("скобка открывается пять плюс семь")
    calculator("скобка открывается скобка открывается пять плюс семь скобка закрывается")
    calculator("скобка закрывается пять плюс семь скобка открывается")
    calculator("пять плюс семь плюс")
    calculator("плюс плюс пять плюс семь")
    calculator("минус минус пять плюс семь")
    calculator("пять умножить семь")
    calculator("пять умножить на плюс семь")
    calculator("пять плюс минус семь")
    calculator("пять скобка открывается плюс скобка закрывается минус семь")
    print()
    while True:
        try:
            print("Введите выражение: ")
            calculator(input())
        except KeyboardInterrupt:
            exit(0)


if __name__ == '__main__':
    main()
