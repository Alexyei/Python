from stdlib_python import stdio


def _search(key, a, lo, hi):
    if hi <= lo:
        return -1
    mid = (lo + hi) // 2

    if key < a[mid]:
        return _search(key, a, lo, mid)
    elif a[mid] < key:
        return _search(key, a, mid + 1, hi)
    else:
        return mid


def search(key, a):
    return _search(key, a, 0, len(a))


def main():
    a = ["alice@home", "bob@office", "carl@beach", "deve@boat"]

    keys = ["bob@office", "carl@beach", "marvin@spam", "bob@office", "mallory@spam", "deve@boat", "eve@airport",
            "alice@home"]
    print("Отсортированный массив: ")
    for key in keys:
        if search(key, a) < 0:
            stdio.writeln(key)

    print()
    print("Неотсортированный массив: ")
    a.reverse()
    for key in keys:
        if search(key, a) < 0:
            stdio.writeln(key)


if __name__ == '__main__':
    main()
