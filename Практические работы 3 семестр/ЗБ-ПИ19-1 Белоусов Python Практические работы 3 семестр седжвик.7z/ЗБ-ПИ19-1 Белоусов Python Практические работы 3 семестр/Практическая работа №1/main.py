import sys
from stdlib_python import stddraw
import luminance
from stdlib_python.picture import Picture
from stdlib_python import color


def main():
    grayColors = {}
    pic = Picture(sys.argv[1])
    for col in range(pic.width()):
        for row in range(pic.height()):
            pixel = pic.get(col, row)
            gray = luminance.toGray(pixel)
            grayColors[gray.getRed()] = grayColors.get(gray.getRed(), 0) + 1

    stddraw.setCanvasSize(256 * 4 + 1, 400)
    stddraw.setYscale(0, grayColors.get(max(grayColors, key=grayColors.get), 0) + 400)
    stddraw.setXscale(0, 256 * 4)
    stddraw.clear(color.Color(0, 220, 0))
    for i in range(256):
        count = grayColors.get(i, 0)
        stddraw.setPenColor(color.Color(i, i, i))
        stddraw.filledRectangle(i * 4 + 1.0, 0, 4.0, count)

    stddraw.show()


if __name__ == "__main__":
    main()
